package roverAPI;

import java.awt.Point;
import java.util.ArrayList;

/*
============================================================================================================
The following are my assumptions:
============================================================================================================
The grid starts from 0,0 to a positive value (x,y) defined by the user.
The user will add the coordinates of the obstacles using the method provided (addObstacles)
The list of commands will be in the form of L, R, F, B
L, R indicates a turn 
F, B indicates a move

============================================================================================================
The following are the functions available for public use:
============================================================================================================

public static void setCoord(int x, int y)
	- sets the coordinate of the rover

public static void setFacing(char f)
	- sets the facing of the rover

public static void setGridSize(int x, int y)
	- sets the size of the grid

public static void addObstacles(int x, int y)
	- adds a obstacle to the grid

public static void turn(char cmd)
	- turns the rover L , R

public static void move(char cmd)
	- moves the rover F, B

public static void executeCommands(char[] commands)
	- executes the list of commands
	
============================================================================================================	
*/

public class Rover {

	private static Point currCoord;
	private static Point gridSize;
	private static char facing;	
	private static ArrayList<Point> obstacles = new ArrayList<Point>();	
	
	//Checks if the rover has been initialized
	private static boolean checkInit()
	{
		boolean returnVal = true;
		
		if(currCoord == null)
		{		
			System.out.print("Error: The coordinates of the rover has not been set.");
			returnVal = false;
		}
		
		if(gridSize == null)
		{	
			System.out.print("Error: The coordinates grid size has not been set.");
			returnVal = false;
		}
		
		if(facing == '\0')
		{	
			System.out.print("Error: The facing of the rover has not been set.");
			returnVal = false;
		}
		
		return returnVal;
	}
	
	//Sets the coordinate of the rover
	public static void setCoord(int x, int y)
	{
		if(x >= 0 && y >=0 )
			currCoord = new Point(x, y);
		else
			System.out.println("Error: Only postive integers are allowed");
	}
	
	//Sets the facing of the rover
	public static void setFacing(char f)
	{
		//error checking
		if(f != 'N' && f != 'S' && f != 'E' && f != 'W' )
		{				
			System.out.print("Error: Invalid facing, only N, S, E, or W is allowed.");			
		}
		else		
			facing = f;
	}
	
	//Sets the grid size
	public static void setGridSize(int x, int y)
	{
		if(x >= 0 && y >=0 )
			gridSize = new Point(x, y);
		else
			System.out.println("Error: Only postive integers are allowed");
	}
	
	//Adds obstacles to the grid
	public static void addObstacles(int x, int y)
	{
		//if a valid coordinate is provided, adds it to the obstacles arraylist
		if(x >= 0 && y >=0 )
		{
			Point o = new Point(x, y);
			obstacles.add(o);
		}
		else
			System.out.println("Error: Only postive integers are allowed");
	}
	
	//Turns the facing of the rover
	public static void turn(char cmd)
	{
		if(checkInit() == false)
			return;		
		
		switch(facing) {
		   case 'N' :
		      if(cmd == 'L')
		    	  facing = 'W';		      
		      else if(cmd == 'R')
		    	  facing = 'E';
		      break;
		   
		   case 'S' :
			   if(cmd == 'L')
				   facing = 'E';		      
			   else if(cmd == 'R')
				   facing = 'W';			      
		      break;
		      
		   case 'E' :
			   if(cmd == 'L')
				   facing = 'N';		      
			   else if(cmd == 'R')
				   facing = 'S';			      
		      break;
			      
		   case 'W' :
			   if(cmd == 'L')
				   facing = 'S';		      
			   else if(cmd == 'R')
				   facing = 'N';			      
		      break;
		}			
	}	
	
	//Executes the list of commands provided to the rover
	public static void executeCommands(char[] commands)
	{
		char cmd;		
		
		for (int a = 0; a < commands.length ; a++) {
			
			cmd = commands[a];
			
			//L, R indicates a turn
			if(cmd == 'L' || cmd == 'R')
				turn(cmd);
			//F, B indicates a move
			else if(cmd == 'F' || cmd == 'B')
				move(cmd);
		}
	}
	
	public static void move(char cmd)
	{
		Point destCoord = getMoveDest(cmd);
		
		//if dest coord is null means the current coordinates of the rover has not been initialized
		if(destCoord == null)
			return;
		
		boolean hitObstacle = false;
		
		//loops through the array list of obstacles to check if the destination is a obstacle
		for (Point p : obstacles) {
		    if(p.equals(destCoord))
		    	hitObstacle = true;
		}
		
		if(hitObstacle == true)
		{
			System.out.println("Obstacle encountered at coordinates ("+ destCoord.x + "," + destCoord.y +")");
			System.out.println("Moving back to the previous point ("+ currCoord.x + "," + currCoord.y +")");
		}
		else
		{
			//moves to the new location
			currCoord.setLocation(destCoord);
		}
	}

	//gets the destination coordinate of the move
	private static Point getMoveDest(char cmd)
	{
		if(checkInit() == false)
			return null;		
			
		int tempX, tempY;
		int gridX, gridY;
		Point destCoord = new Point(-1,-1);
		
		gridX = gridSize.x;
		gridY = gridSize.y;
		tempY = currCoord.y;
		tempX = currCoord.x;
		
		switch(facing) {
		   case 'N' :
		      if(cmd == 'F')
		      {
		    	  tempY++;
		    	  //wraps back to 0
		    	  if(tempY > gridY)
		    		  tempY = 0;
		    	  destCoord.setLocation(tempX, tempY);
		      }
		      else if(cmd == 'B')
		      {
		    	  tempY--;
		    	//wraps back to the max value of Y
		    	  if(tempY < 0)
		    		  tempY = gridY;
		    	  destCoord.setLocation(tempX, tempY);
		      }
		      break;
		   
		   case 'S' :
		      if(cmd == 'F')
		      {
		    	  tempY--;
		    	  if(tempY < 0)
		    		  tempY = gridY;
		    	  destCoord.setLocation(tempX, tempY);
		      }
		      else if(cmd == 'B')
		      {
		    	  tempY++;
		    	  if(tempY > gridY)
		    		  tempY = 0;
		    	  destCoord.setLocation(tempX, tempY);
		      }
		      break;
		      
		   case 'E' :
		      if(cmd == 'F')
		      {
		    	  tempX++;
		    	  if(tempX > gridX)
		    		  tempX = 0;		    	  
		    	  destCoord.setLocation(tempX, tempY);
		      }
		      else if(cmd == 'B')
		      {
		    	  tempX--;
		    	  if(tempX < 0 )
		    		  tempX = gridX;
		    	  destCoord.setLocation(tempX, tempY);
		      }
			  break;
			      
		   case 'W' :
		      if(cmd == 'F')
		      {
		    	  tempX--;
		    	  if(tempX < 0 )
		    		  tempX = gridX;
		    	  destCoord.setLocation(tempX, tempY);
		      }
		      else if(cmd == 'B')
		      {
		    	  tempX++;
		    	  if(tempX > gridX)
		    		  tempX = 0;
		    	  destCoord.setLocation(tempX, tempY);
		      }
			  break;
		}
		
		return destCoord;
		
	}
	
	//returns the current coordinate of the rover
	public static Point getCoord()
	{
		return currCoord;
	}
	
	//returns the current facing of the rover
	public static char getFacing()
	{
		return facing;
	}
}
