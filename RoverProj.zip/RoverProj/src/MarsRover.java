import roverAPI.Rover;

public class MarsRover {

	public static void main(String[] args)
	{ 	
		//initialize the grid and rover
		Rover.setGridSize(10, 10);
		Rover.setFacing('N');		
		Rover.setCoord(0, 0);
		Rover.addObstacles(9, 3);
		
		System.out.println("Before executing commands: ");
		System.out.println("Rover Facing: " + Rover.getFacing());
		System.out.println("Rover Coordinates: (" +Rover.getCoord().x + ","+ Rover.getCoord().y + ")");
 
		char[] commands=   {'F', 'F', 'F', 'L', 'F', 'F', 'L', 'B', 'B', 'R', 'F', 'F', 'L', 'B'};
		
		System.out.println("After executing commands: ");
		
		//expected rover to be moved to (8,6) facing S after executing command
		Rover.executeCommands(commands);		
		System.out.println("Rover Facing: " + Rover.getFacing());
		System.out.println("Rover Coordinates: (" +Rover.getCoord().x + ","+ Rover.getCoord().y + ")");
	}
}
